% 1 volno
% 0 prekazka

load('bludisko1');
n=size(b,1);
image(b+1);colormap(hsv(5));
set(gca,'xtick',[1:1:n]);
set(gca,'ytick',[1:1:n]);